import cv2
import numpy as np
import math
from math import atan2, cos, sin, sqrt, pi
from itertools import combinations
import freenect

def get_blue_coord(hough_circles):
    circles = np.array(hough_circles)
    x_components = circles[0][:]

    for pair in list(combinations(x_components, 2)):
        diff_x = abs(pair[0][0] - pair[1][0])
#         print(diff_x)
        if 18 < diff_x < 22:
#             print(pair)
            if pair[0][0] > pair[1][0]:
                blue_coord = pair[0]
                return blue_coord
            else:
                blue_coord = pair[1]
                return blue_coord


def detect_blue_button(img):

#      # Load the image
#     img = cv2.imread(image_file)

    # Convert to grayscale.
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Blur using 3 * 3 kernel.
#     gray_blurred = cv2.blur(gray, (3, 3))
#     gray_blurred = gray

    # Apply Hough transform on the blurred image.
    detected_circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 10,
                                        param1 = 50, param2 = 30, minRadius = 9, maxRadius = 15)

    if detected_circles is not None:

        blue_button_coordinates = get_blue_coord(detected_circles)

        try:
            # Convert the circle parameters a, b and r to integers.
            pt = np.uint16(np.around(blue_button_coordinates))
            a, b, r = pt[0], pt[1], pt[2]

        except Exception as e:
            print("error in func detect_blue_button(): ", e)
            a = 0
            b = 0
            r = 1

        label = "Start Button: (" + str(a) + ", " + str(b) + ")"
        textbox = cv2.rectangle(img, (a+15, b-25), (a + 250, b + 10), (255,255,255), -1)
        cv2.putText(img, label, (a+20, b), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
        # Draw the circumference of the circle.
        cv2.circle(img, (a, b), r, (0, 255, 0), 2)

        # Draw a small circle (of radius 1) to show the center.
        cv2.circle(img, (a, b), 1, (0, 0, 255), 3)



    return img, (a, b)


def drawAxis(img, p_, q_, color, scale):
    p = list(p_)
    q = list(q_)

    ## [visualization1]
    angle = atan2(p[1] - q[1], p[0] - q[0]) # angle in radians
    hypotenuse = sqrt((p[1] - q[1]) * (p[1] - q[1]) + (p[0] - q[0]) * (p[0] - q[0]))

    # Here we lengthen the arrow by a factor of scale
    q[0] = p[0] - scale * hypotenuse * cos(angle)
    q[1] = p[1] - scale * hypotenuse * sin(angle)
    cv2.line(img, (int(p[0]), int(p[1])), (int(q[0]), int(q[1])), color, 3, cv2.LINE_AA)

    # create the arrow hooks
    p[0] = q[0] + 9 * cos(angle + pi / 4)
    p[1] = q[1] + 9 * sin(angle + pi / 4)
    cv2.line(img, (int(p[0]), int(p[1])), (int(q[0]), int(q[1])), color, 3, cv2.LINE_AA)

    p[0] = q[0] + 9 * cos(angle - pi / 4)
    p[1] = q[1] + 9 * sin(angle - pi / 4)
    cv2.line(img, (int(p[0]), int(p[1])), (int(q[0]), int(q[1])), color, 3, cv2.LINE_AA)
    ## [visualization1]

def getOrientation(pts, img):
    ## [pca]
    # Construct a buffer used by the pca analysis
    sz = len(pts)
    data_pts = np.empty((sz, 2), dtype=np.float64)
    for i in range(data_pts.shape[0]):
        data_pts[i,0] = pts[i,0,0]
        data_pts[i,1] = pts[i,0,1]

    # Perform PCA analysis
    mean = np.empty((0))
    mean, eigenvectors, eigenvalues = cv2.PCACompute2(data_pts, mean)

    # Store the center of the object
    cntr = (int(mean[0,0]), int(mean[0,1]))
    ## [pca]

    ## [visualization]
    # Draw the principal components
    cv2.circle(img, cntr, 3, (255, 0, 255), 2)
    p1 = (cntr[0] + 0.02 * eigenvectors[0,0] * eigenvalues[0,0], cntr[1] + 0.02 * eigenvectors[0,1] * eigenvalues[0,0])
    p2 = (cntr[0] - 0.02 * eigenvectors[1,0] * eigenvalues[1,0], cntr[1] - 0.02 * eigenvectors[1,1] * eigenvalues[1,0])
    drawAxis(img, cntr, p1, (255, 255, 0), 1)
    drawAxis(img, cntr, p2, (0, 0, 255), 5)

    angle = atan2(eigenvectors[0,1], eigenvectors[0,0]) # orientation in radians
    angle_rad = angle
    angle_deg = -np.rad2deg(angle)
    repr_angle = round_off(angle_deg)
    ## [visualization]

    # Label with the rotation angle
    label = "  Rotation Angle: " + str(repr_angle) + " degrees"
    textbox = cv2.rectangle(img, (cntr[0], cntr[1]-25), (cntr[0] + 250, cntr[1] + 10), (255,255,255), -1)
    cv2.putText(img, label, (cntr[0], cntr[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)

    return angle_rad, angle_deg


def detect_task_board(img):

#     # Load the image
#     img = cv2.imread(image_file)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Convert image to binary
    _, bw = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    # Find all the contours in the thresholded image
    contours, _ = cv2.findContours(bw, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

    for i, c in enumerate(contours):

        # Calculate the area of each contour
        area = cv2.contourArea(c)

        # Ignore contours that are too small or too large
        if area < 3700 or 100000 < area:
#         if 83000 < area < 84500:
            continue

#         img = detect_buttons(image)
        print("area", area)
        # Draw each contour only for visualisation purposes
        cv2.drawContours(img, contours, i, (0, 0, 255), 2)

        # Find the orientation of each shape
        angle_rad, angle_deg = getOrientation(c, img)

    return img, angle_deg



def detect_from_kinect(img):

     # Load the image
#     img = cv2.imread(image_file)

    # Convert to grayscale.
#     img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    task_board_img, angle_deg = detect_task_board(img)
    blue_button_img, blue_coord = detect_blue_button(img)

    print("FINAL ------------------")
    print("angle_deg      | ", angle_deg)
    print("button_centres | ", blue_coord)

# #     for matplotlib on jupyter notebook
#     blue_button_img = cv2.cvtColor(blue_button_img, cv2.COLOR_BGR2RGB)
#     plt.imshow(blue_button_img)
#     plt.title('my picture')
#     plt.show()


    cv2.imshow("Detected Blue Start Button", blue_button_img)
#     cv2.imshow("Detected Task Board", task_board_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    return angle_deg, blue_coord


# def detect(image_file):

#      # Load the image
#     img = cv2.imread(image_file)

#     # Convert to grayscale.
# #     img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

#     task_board_img, angle_deg = detect_task_board(img)
#     blue_button_img, blue_coord = detect_blue_button(img)

#     print("FINAL ------------------")
#     print("angle_deg      | ", angle_deg)
#     print("button_centres | ", blue_coord)

# # #     for matplotlib on jupyter notebook
# #     blue_button_img = cv2.cvtColor(blue_button_img, cv2.COLOR_BGR2RGB)
# #     plt.imshow(blue_button_img)
# #     plt.title('my picture')
# #     plt.show()


#     cv2.imshow("Detected Blue Start Button", blue_button_img)
# #     cv2.imshow("Detected Task Board", task_board_img)
#     cv2.waitKey(0)
#     cv2.destroyAllWindows()

#     return angle_deg, blue_coord


#function to get RGB image from kinect
def get_video():
    array, success = freenect.sync_get_video()
    array = cv2.cvtColor(array,cv2.COLOR_RGB2BGR)
    return array, success


# if __name__ == "__main__":

#     # image_name = "frame1.jpg"
#     image_name = "frame100.jpg"
#     # image_name = "frame175.jpg"
#     # image_name = "zero_image.png"

#     images_dir = "/home/nemo/code/repos/robothon/code_repos/notebooks/"
#     image_path = images_dir + image_name

#     angle_deg, blue_coord = detect(image_path)


def round_off(value):
    return round(value, 2)

def get_final_values(angle_deg, blue_coord):

    offset_angle = 1.67

    angle = round_off(angle_deg)
    final_angle = angle - offset_angle

    return angle_deg, blue_coord




def get_values():
#     try:
    while(1):
        frame, success = get_video()
        if success:
            cv2.imshow('RGB image', frame)
            angle_deg, blue_coord = detect_from_kinect(frame)
            if blue_coord != (0,0):
                break
                return get_final_values(angle_deg, blue_coord)
            else:
                continue

        # quit program when 'esc' key is pressed
#         k = cv2.waitKey(5) & 0xFF
#         if k == 27:
#             break
#     cv2.destroyAllWindows()

#     except Exception as e:

#         print(e)
#         cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
#         while True:
        angle_deg, blue_coord = get_values()
        print("angle:                    ", angle_deg)
        print("start button coordinates: ", blue_coord)


    except Exception as e:
        print("exception occured. shutting down. Error: ", e)
        cv2.destroyAllWindows()

    print("shutting down...")
    cv2.destroyAllWindows()
#         k = cv2.waitKey(5) & 0xFF
#         if k == 27:
#             break
#         cv2.destroyAllWindows()
#     except Exception as e:
#         print("main loop error")
#     try:
#         while(1):
#             frame, success = get_video()
#             if success:
#                 cv2.imshow('RGB image', frame)
#                 angle_deg, blue_coord = detect_from_kinect(frame)

#     #                 detect_from_kinect(frame)

#             # quit program when 'esc' key is pressed


#             k = cv2.waitKey(5) & 0xFF
#             if k == 27:
#                 break
#         cv2.destroyAllWindows()

#     except Exception as e:

#         print(e)
#         cv2.destroyAllWindows()
