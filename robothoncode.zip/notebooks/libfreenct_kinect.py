#import the necessary modules
import freenect
import cv2
import numpy as np
import time

#function to get RGB image from kinect
def get_video():
    array, success = freenect.sync_get_video()
    array = cv2.cvtColor(array,cv2.COLOR_RGB2BGR)
    return array, success

#function to get depth image from kinect
def get_depth():
    array, success = freenect.sync_get_depth()
    array = array.astype(np.uint8)
    return array, success

if __name__ == "__main__":

    # num images to save in each run
    images_limit = 10
    # no. of seconds before image is taken
    time_interval = 3

    # counters
    limit_count = 0
    count = 201

    while (limit_count < images_limit):
        frame, success = get_video()
        if success:
            cv2.imshow('RGB image',frame)
            cv2.imwrite("./zero_image.png", frame)

        # quit program when 'esc' key is pressed
        k = cv2.waitKey(5) & 0xFF
        if k == 27:
            break
    cv2.destroyAllWindows()
